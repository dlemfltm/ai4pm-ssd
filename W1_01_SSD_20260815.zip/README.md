# 1조 SSD · 예상손익 LLM Wiki — 1주차 제출

더미 예상손익 자료를 찾아 **AI와 팀원이 다시 쓸 수 있는 팀 지식(LLM Wiki)** 으로 정리한 결과물이다.
AI에게 바로 코딩시키지 않고, **근거 있는 자료를 먼저 갖춘 뒤** 그 위에서 일하게 하는 것이 목표다.

## 폴더 구조

| 폴더 | 내용 |
|---|---|
| `sources/` | 확인한 원문 6건(요지) + 확인한 자료 집계·판정 |
| `wiki/` | 정리한 지식 — 목차(index)·이력(log)·자료대장·source 6·concept 8·decision 2·project 1 |
| `review/` | 교차 검토(동료 검토) + 검사기(wiki_lint) 로그 |
| `submission/` | 프로젝트 설명·질문과답변·참고도서·핵심질문답변·제출요약·3분 설명자료 |

## 읽는 순서 (처음 보는 사람용)

1. `submission/프로젝트설명.md` — 이 프로젝트가 무엇인지
2. `submission/질문과답변.md` — 개발 질문 5개
3. `sources/확인한-자료.md` · `wiki/자료대장.md` — 어떤 자료에 근거했나
4. `wiki/index.md` — 정리한 지식 목차
5. `submission/핵심질문답변.md` · `submission/제출요약.md` — 결론과 요약

## 상태

- 검사기(wiki_lint) 결과: **오류 0 · 경고 0 PASS** (`review/wiki-lint-log.md`)
- 지식·source·decision 문서: 전부 `reviewed`
- 확인 자료 8건 중 공식·승인 3건 이상

## 남은 사람 몫 (제출요약 "다음 단계" 참조)

- 교차 검토 실제 O/X 채우기 (`review/교차검토.md`)
- `actual` 빈 값 처리·차이 임계값 수치 확정
- 민감정보 최종 점검 + LMS 업로드

> 참고: 이 패키지는 제출용으로 재배치한 것이며, 원본 작업 저장소에서는 `sources/`가 `vault/raw/`, `wiki/`가 `vault/wiki/`에 해당한다. wiki 문서의 `[[sources/...]]` 링크는 이 구조 기준으로 연결된다.
